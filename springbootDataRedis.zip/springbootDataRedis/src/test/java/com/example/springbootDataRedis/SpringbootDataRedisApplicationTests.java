package com.example.springbootDataRedis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootDataRedisApplicationTests {

	@Test
	void contextLoads() {
	}

}
