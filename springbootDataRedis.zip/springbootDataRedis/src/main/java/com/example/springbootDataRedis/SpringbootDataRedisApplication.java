package com.example.springbootDataRedis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootDataRedisApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootDataRedisApplication.class, args);
	}

}
