package com.example.hmdianping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HmDianpingApplicationTests {

	@Test
	void contextLoads() {
	}

}
