package com.example.hmdianping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HmDianpingApplication {

	public static void main(String[] args) {
		SpringApplication.run(HmDianpingApplication.class, args);
	}

}
